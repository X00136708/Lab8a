package controllers;

import play.mvc.*;

import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.*;
import javax.inject.Inject;

import models.*;

import views.html.*;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        List<Product> prodList = Product.findAll();
        return ok(index.render(prodList));
    }
    public Result customer() {
        List<Customer> custList = Customer.findAll();
        return ok(customer.render(custList));
    }
    public Result addProduct(){
        Form<Product> prodForm = ff.form(Product.class);
        return ok(addProduct.render(prodForm));
    }

    public Result addCustomer(){
        Form<Customer> custForm = ff.form(Customer.class);
        return ok(addCustomer.render(custForm));
    }

    private FormFactory ff;

    @Inject
    public HomeController(FormFactory f){
        this.ff = f;
    }

    public Result addProductSubmit(){

        Form<Product> prodSubmit = ff.form(Product.class).bindFromRequest();

        if (prodSubmit.hasErrors()) {
            return badRequest(addProduct.render(prodSubmit));
        } else {
            Product newProduct = prodSubmit.get();
            newProduct.save();
            flash("Success.", "Product: "+ newProduct.getName() + " was successfully added");
            return redirect(controllers.routes.HomeController.index());
        }
    }

    public Result addCustomerSubmit(){
        
                Form<Customer> custSubmit = ff.form(Customer.class).bindFromRequest();
        
                if (custSubmit.hasErrors()) {
                    return badRequest(addCustomer.render(custSubmit));
                } else {
                    Customer newCustomer = custSubmit.get();
                    newCustomer.save();
                    flash("success", "Customer "+ newCustomer.getName() + " was added");
                    return redirect(controllers.routes.HomeController.customer());
                }
            }

            public Result deleteProduct(Long id){
                Product.find.ref(id).delete();
                flash("success", "Product has been deleted");
                return redirect(routes.HomeController.index());
            }

            public Result deleteCustomer(Long id){
                Customer.find.ref(id).delete();
                flash("success", "Customer has been deleted");
                return redirect(routes.HomeController.customer());
            }
}
